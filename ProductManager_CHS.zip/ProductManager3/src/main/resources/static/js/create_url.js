/**
 * 
 */
function buscarMarca(){
    window.location = "buscarPorMarca/" + document.getElementById('marca').value;
  }

function buscarPrecioMayor(){
    window.location = "buscarPorPrecio/" + document.getElementById('precio').value;
  }